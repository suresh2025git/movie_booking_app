package com.moviebooking.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.moviebooking.entity.Theatre;
import com.moviebooking.repository.TheatreRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TheatreService {
	

	    private final TheatreRepository theatreRepository;

	    public Theatre create(Theatre theatre) {
	        return theatreRepository.save(theatre);
	    }

	    public List<Theatre> getAll() {
	        return theatreRepository.findAll();
	    }

	    public Theatre getById(Long id) {
	        return theatreRepository.findById(id)
	                .orElseThrow(() -> new RuntimeException("Theatre not found with id: " + id));
	    }

	    public Theatre update(Long id, Theatre updated) {
	        Theatre existing = getById(id);

	        existing.setName(updated.getName());
	       
	        return theatreRepository.save(existing);
	    }

	    public void delete(Long id) {
	        if (!theatreRepository.existsById(id)) {
	            throw new RuntimeException("Theatre not found with id: " + id);
	        }
	        theatreRepository.deleteById(id);
	    }
}
