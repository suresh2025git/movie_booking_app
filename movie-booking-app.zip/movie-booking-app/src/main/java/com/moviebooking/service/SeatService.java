package com.moviebooking.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.moviebooking.entity.Seat;
import com.moviebooking.repository.SeatRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SeatService {

	    private final SeatRepository seatRepository;

	    public Seat create(Seat seat) {
	        return seatRepository.save(seat);
	    }

	    public List<Seat> getAll() {
	        return seatRepository.findAll();
	    }

	    public Seat getById(Long id) {
	        return seatRepository.findById(id)
	                .orElseThrow(() -> new RuntimeException("Seat not found with id: " + id));
	    }

	    public Seat update(Long id, Seat updated) {
	        Seat existing = getById(id);

	        existing.setSeatNumber(updated.getSeatNumber());
	        existing.setSeatType(updated.getSeatType());
	        existing.setScreen(updated.getScreen());

	        return seatRepository.save(existing);
	    }

	    public void delete(Long id) {
	        if (!seatRepository.existsById(id)) {
	            throw new RuntimeException("Seat not found with id: " + id);
	        }
	        seatRepository.deleteById(id);
	    }
}
