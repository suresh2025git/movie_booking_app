package com.moviebooking.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.moviebooking.entity.Screen;
import com.moviebooking.repository.ScreenRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ScreenService {

	    private final ScreenRepository screenRepository;

	    public Screen create(Screen screen) {
	        return screenRepository.save(screen);
	    }

	    public List<Screen> getAll() {
	        return screenRepository.findAll();
	    }

	    public Screen getById(Long id) {
	        return screenRepository.findById(id)
	                .orElseThrow(() -> new RuntimeException("Screen not found with id: " + id));
	    }

	    public Screen update(Long id, Screen updated) {
	        Screen existing = getById(id);

	        existing.setName(updated.getName());
	        existing.setTheatre(updated.getTheatre());

	        return screenRepository.save(existing);
	    }

	    public void delete(Long id) {
	        if (!screenRepository.existsById(id)) {
	            throw new RuntimeException("Screen not found with id: " + id);
	        }
	        screenRepository.deleteById(id);
	    }
}
