package com.moviebooking.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.moviebooking.entity.MovieShow;
import com.moviebooking.repository.ShowRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ShowService {

	    private final ShowRepository showRepository;

	    public MovieShow create(MovieShow show) {
	        return showRepository.save(show);
	    }

	    public List<MovieShow> getAll() {
	        return showRepository.findAll();
	    }

	    public MovieShow getById(Long id) {
	        return showRepository.findById(id)
	                .orElseThrow(() -> new RuntimeException("Show not found with id: " + id));
	    }

	    public MovieShow update(Long id, MovieShow updated) {
	        MovieShow existing = getById(id);

	        existing.setMovie(updated.getMovie());
	        existing.setScreen(updated.getScreen());
	        existing.setShowTime(updated.getShowTime());
	        existing.setPrice(updated.getPrice());

	        return showRepository.save(existing);
	    }

	    public void delete(Long id) {
	        if (!showRepository.existsById(id)) {
	            throw new RuntimeException("Show not found with id: " + id);
	        }
	        showRepository.deleteById(id);
	    }
}
