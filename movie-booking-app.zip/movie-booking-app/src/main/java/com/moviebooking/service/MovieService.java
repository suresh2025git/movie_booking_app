package com.moviebooking.service;
import com.moviebooking.entity.Movie;
import com.moviebooking.repository.MovieRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MovieService {

	    private final MovieRepository movieRepository;

	    // CREATE
	    public Movie createMovie(Movie movie) {
	        return movieRepository.save(movie);
	    }

	    // READ ALL
	    public List<Movie> getAllMovies() {
	        return movieRepository.findAll();
	    }

	    // READ BY ID
	    public Movie getMovieById(Long id) {
	        return movieRepository.findById(id)
	                .orElseThrow(() -> new RuntimeException("Movie not found with id: " + id));
	    }

	    // UPDATE
	    public Movie updateMovie(Long id, Movie updatedMovie) {
	        Movie existing = getMovieById(id);

	        existing.setTitle(updatedMovie.getTitle());
	        existing.setLanguage(updatedMovie.getLanguage());
	        existing.setDuration(updatedMovie.getDuration());
	        existing.setDescription(updatedMovie.getDescription());
	        existing.setRating(updatedMovie.getRating());
	        existing.setReleaseDate(updatedMovie.getReleaseDate());

	        return movieRepository.save(existing);
	    }

	    // DELETE
	    public void deleteMovie(Long id) {
	        if (!movieRepository.existsById(id)) {
	            throw new RuntimeException("Movie not found with id: " + id);
	        }
	        movieRepository.deleteById(id);
	    }
}
