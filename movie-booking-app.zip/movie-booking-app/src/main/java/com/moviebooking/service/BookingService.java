package com.moviebooking.service;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;

import com.moviebooking.entity.Booking;
import com.moviebooking.enums.BookingStatus;
import com.moviebooking.repository.BookingRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BookingService {

	    private final BookingRepository bookingRepository;

	    public Booking createBooking(Booking booking) {
	        booking.setStatus(BookingStatus.PENDING);
	        booking.setBookingTime(LocalDateTime.now());
	        return bookingRepository.save(booking);
	    }
}
