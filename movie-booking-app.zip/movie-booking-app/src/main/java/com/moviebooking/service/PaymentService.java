package com.moviebooking.service;

import java.util.UUID;

import org.springframework.stereotype.Service;

import com.moviebooking.entity.Booking;
import com.moviebooking.entity.Payment;
import com.moviebooking.enums.BookingStatus;
import com.moviebooking.enums.PaymentMode;
import com.moviebooking.enums.PaymentStatus;
import com.moviebooking.repository.BookingRepository;
import com.moviebooking.repository.PaymentRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PaymentService {

	    private final BookingRepository bookingRepository;
	    private final PaymentRepository paymentRepository;

	    public Payment makePayment(Long bookingId, PaymentMode mode) {

	        Booking booking = bookingRepository.findById(bookingId).orElseThrow();

	        Payment payment = new Payment();
	        payment.setBooking(booking);
	        payment.setAmount(booking.getTotalAmount());
	        payment.setMode(mode);
	        payment.setStatus(PaymentStatus.SUCCESS);
	        payment.setTransactionId(UUID.randomUUID().toString());

	        booking.setStatus(BookingStatus.CONFIRMED);
	        bookingRepository.save(booking);

	        return paymentRepository.save(payment);
	    }
}
