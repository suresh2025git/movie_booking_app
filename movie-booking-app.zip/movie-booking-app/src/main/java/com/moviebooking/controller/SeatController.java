package com.moviebooking.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.moviebooking.entity.Seat;
import com.moviebooking.service.SeatService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/seats")
@RequiredArgsConstructor
public class SeatController {

	    private final SeatService seatService;

	    @PostMapping
	    public ResponseEntity<Seat> create(@RequestBody Seat seat) {
	        return new ResponseEntity<>(seatService.create(seat), HttpStatus.CREATED);
	    }

	    @GetMapping
	    public ResponseEntity<List<Seat>> getAll() {
	        return ResponseEntity.ok(seatService.getAll());
	    }

	    @GetMapping("/{id}")
	    public ResponseEntity<Seat> getById(@PathVariable Long id) {
	        return ResponseEntity.ok(seatService.getById(id));
	    }

	    @PutMapping("/{id}")
	    public ResponseEntity<Seat> update(
	            @PathVariable Long id,
	            @RequestBody Seat seat) {
	        return ResponseEntity.ok(seatService.update(id, seat));
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<String> delete(@PathVariable Long id) {
	        seatService.delete(id);
	        return ResponseEntity.ok("Seat deleted successfully");
	    }

}
