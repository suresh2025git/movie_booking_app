package com.moviebooking.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.moviebooking.entity.MovieShow;
import com.moviebooking.service.ShowService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/shows")
@RequiredArgsConstructor
public class ShowController {

	    private final ShowService showService;

	    @PostMapping
	    public ResponseEntity<MovieShow> create(@RequestBody MovieShow show) {
	        return new ResponseEntity<>(showService.create(show), HttpStatus.CREATED);
	    }

	    @GetMapping
	    public ResponseEntity<List<MovieShow>> getAll() {
	        return ResponseEntity.ok(showService.getAll());
	    }

	    @GetMapping("/{id}")
	    public ResponseEntity<MovieShow> getById(@PathVariable Long id) {
	        return ResponseEntity.ok(showService.getById(id));
	    }

	    @PutMapping("/{id}")
	    public ResponseEntity<MovieShow> update(
	            @PathVariable Long id,
	            @RequestBody MovieShow show) {
	        return ResponseEntity.ok(showService.update(id, show));
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<String> delete(@PathVariable Long id) {
	        showService.delete(id);
	        return ResponseEntity.ok("Show deleted successfully");
	    }

}
