package com.moviebooking.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.moviebooking.entity.Payment;
import com.moviebooking.enums.PaymentMode;
import com.moviebooking.service.PaymentService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

	    private final PaymentService paymentService;

	    @PostMapping("/{bookingId}")
	    public Payment pay(@PathVariable Long bookingId,
	                       @RequestParam PaymentMode mode) {
	        return paymentService.makePayment(bookingId, mode);
	    }
}
