package com.moviebooking.controller;
import com.moviebooking.entity.Movie;
import com.moviebooking.service.MovieService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/movies")
@RequiredArgsConstructor
public class MovieController {

	    private final MovieService movieService;

	    // ================= CREATE =================
	    // POST /movies
	    @PostMapping
	    public ResponseEntity<Movie> createMovie(@RequestBody Movie movie) {
	        Movie savedMovie = movieService.createMovie(movie);
	        return new ResponseEntity<>(savedMovie, HttpStatus.CREATED);
	    }

	    // ================= READ ALL =================
	    // GET /movies
	    @GetMapping
	    public ResponseEntity<List<Movie>> getAllMovies() {
	        return ResponseEntity.ok(movieService.getAllMovies());
	    }

	    // ================= READ BY ID =================
	    // GET /movies/{id}
	    @GetMapping("/{id}")
	    public ResponseEntity<Movie> getMovieById(@PathVariable Long id) {
	        return ResponseEntity.ok(movieService.getMovieById(id));
	    }

	    // ================= UPDATE =================
	    // PUT /movies/{id}
	    @PutMapping("/{id}")
	    public ResponseEntity<Movie> updateMovie(
	            @PathVariable Long id,
	            @RequestBody Movie movie) {
	        return ResponseEntity.ok(movieService.updateMovie(id, movie));
	    }

	    // ================= DELETE =================
	    // DELETE /movies/{id}
	    @DeleteMapping("/{id}")
	    public ResponseEntity<String> deleteMovie(@PathVariable Long id) {
	        movieService.deleteMovie(id);
	        return ResponseEntity.ok("Movie deleted successfully");
	    }
}
