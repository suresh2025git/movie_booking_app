package com.moviebooking.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.moviebooking.entity.Theatre;
import com.moviebooking.service.TheatreService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/theatres")
@RequiredArgsConstructor
public class TheatreController {
	
	    private final TheatreService theatreService;

	    @PostMapping
	    public ResponseEntity<Theatre> create(@RequestBody Theatre theatre) {
	        return new ResponseEntity<>(theatreService.create(theatre), HttpStatus.CREATED);
	    }

	    @GetMapping
	    public ResponseEntity<List<Theatre>> getAll() {
	        return ResponseEntity.ok(theatreService.getAll());
	    }

	    @GetMapping("/{id}")
	    public ResponseEntity<Theatre> getById(@PathVariable Long id) {
	        return ResponseEntity.ok(theatreService.getById(id));
	    }

	    @PutMapping("/{id}")
	    public ResponseEntity<Theatre> update(
	            @PathVariable Long id,
	            @RequestBody Theatre theatre) {
	        return ResponseEntity.ok(theatreService.update(id, theatre));
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<String> delete(@PathVariable Long id) {
	        theatreService.delete(id);
	        return ResponseEntity.ok("Theatre deleted successfully");
	    }
}
