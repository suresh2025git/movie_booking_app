package com.moviebooking.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.moviebooking.entity.Booking;
import com.moviebooking.service.BookingService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

	    private final BookingService bookingService;

	    @PostMapping
	    public Booking create(@RequestBody Booking booking) {
	        return bookingService.createBooking(booking);
	    }
}
