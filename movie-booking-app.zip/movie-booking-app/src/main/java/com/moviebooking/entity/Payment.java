package com.moviebooking.entity;

import com.moviebooking.enums.PaymentMode;
import com.moviebooking.enums.PaymentStatus;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import lombok.Data;

@Entity
@Data
public class Payment {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    private String transactionId;
	    private Double amount;

	    @Enumerated(EnumType.STRING)
	    private PaymentStatus status;

	    @Enumerated(EnumType.STRING)
	    private PaymentMode mode;

	    @OneToOne
	    private Booking booking;

}
