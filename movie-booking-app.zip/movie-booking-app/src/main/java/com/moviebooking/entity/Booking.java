package com.moviebooking.entity;

import java.time.LocalDateTime;

import com.moviebooking.enums.BookingStatus;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Entity
@Data
public class Booking {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    private LocalDateTime bookingTime;
	    private Double totalAmount;

	    @Enumerated(EnumType.STRING)
	    private BookingStatus status;

	    @ManyToOne
	    private User user;

	    @ManyToOne
	    @JoinColumn(name = "show_id")
	    private MovieShow show;


}
