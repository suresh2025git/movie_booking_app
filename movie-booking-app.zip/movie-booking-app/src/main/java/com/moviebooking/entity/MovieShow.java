package com.moviebooking.entity;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "movie_show")
@Data   // Generates getters & setters
public class MovieShow {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    private LocalDateTime showTime;

	    private Double price;   // ✅ ADD THIS FIELD

	    @ManyToOne
	    @JoinColumn(name = "movie_id")
	    private Movie movie;

	    @ManyToOne
	    @JoinColumn(name = "screen_id")
	    private Screen screen;

}
