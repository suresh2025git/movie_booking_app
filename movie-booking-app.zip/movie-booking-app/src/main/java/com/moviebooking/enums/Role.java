package com.moviebooking.enums;

public enum Role {
	 USER, ADMIN
}
