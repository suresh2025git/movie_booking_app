package com.moviebooking.enums;

public enum PaymentMode {
	UPI, CARD, NET_BANKING
}
