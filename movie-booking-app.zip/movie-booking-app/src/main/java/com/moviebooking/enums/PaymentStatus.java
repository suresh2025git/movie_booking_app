package com.moviebooking.enums;

public enum PaymentStatus {
	INITIATED, SUCCESS, FAILED, REFUNDED
}
