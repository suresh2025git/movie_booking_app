package com.moviebooking.enums;

public enum BookingStatus {
	PENDING, CONFIRMED, CANCELLED
}
