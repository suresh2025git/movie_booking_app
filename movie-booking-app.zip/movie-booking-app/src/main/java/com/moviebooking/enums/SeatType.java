package com.moviebooking.enums;

public enum SeatType {
	REGULAR, PREMIUM
}
