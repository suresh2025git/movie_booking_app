package com.moviebooking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.moviebooking.entity.BookingSeat;

public interface BookingSeatRepository extends JpaRepository<BookingSeat, Long>{

}
