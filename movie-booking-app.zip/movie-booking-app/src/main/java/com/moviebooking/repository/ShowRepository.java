package com.moviebooking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.moviebooking.entity.MovieShow;


public interface ShowRepository extends JpaRepository<MovieShow, Long>{

}
