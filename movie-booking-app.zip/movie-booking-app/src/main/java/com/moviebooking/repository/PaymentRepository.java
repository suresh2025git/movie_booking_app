package com.moviebooking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.moviebooking.entity.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Long>{

}
